package edu.cscc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
