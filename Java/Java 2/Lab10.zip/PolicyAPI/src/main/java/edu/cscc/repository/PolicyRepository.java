package edu.cscc.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.cscc.model.Policy;

@Repository
public interface PolicyRepository extends CrudRepository<Policy, Long> {

	Optional<Policy> findByCompanyCodeAndCoverageAmount(String companyCode, double coverageAmount);}
