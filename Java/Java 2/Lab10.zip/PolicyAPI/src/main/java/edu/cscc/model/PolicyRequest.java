package edu.cscc.model;

public class PolicyRequest {
	public String companyCode;
	public double coverageAmount;
	public String getCompanyCode() {
		// TODO Auto-generated method stub
		return null;
	}
	public double getCoverageAmount() {
		// TODO Auto-generated method stub
		return 0;
	}
}
