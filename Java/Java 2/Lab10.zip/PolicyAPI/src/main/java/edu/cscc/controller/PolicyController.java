package edu.cscc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import edu.cscc.model.Policy;
import edu.cscc.model.PolicyRequest;
import edu.cscc.repository.PolicyRepository;

import java.util.Optional;

@RestController
@RequestMapping("/v1")
public class PolicyController {

    @Autowired
    private PolicyRepository policyRepository;

    @GetMapping("/policies")
    public ResponseEntity<Iterable<Policy>> getPolicies() {
        return ResponseEntity.ok(policyRepository.findAll());
    }

    @GetMapping("/policies/{id}")
    public ResponseEntity<Policy> getPolicy(@PathVariable long id) {
        Optional<Policy> policy = policyRepository.findById(id);
        return policy.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/policies")
    public ResponseEntity<Policy> postPolicy(@RequestBody PolicyRequest policyRequest) {
        
        Optional<Policy> existingPolicy = policyRepository.findByCompanyCodeAndCoverageAmount(
            policyRequest.getCompanyCode(), policyRequest.getCoverageAmount()
        );

        if (existingPolicy.isPresent()) {         
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        } else {           
            Policy policy = new Policy(policyRequest.getCompanyCode(), policyRequest.getCoverageAmount());
            policy = policyRepository.save(policy);
            return ResponseEntity.ok(policy);
        }
    }

    @PutMapping("/policies/{id}")
    public ResponseEntity<Policy> putPolicy(@PathVariable long id, @RequestBody PolicyRequest policyRequest) {
        return policyRepository.findById(id).map(existingPolicy -> {
            existingPolicy.setCompanyCode(policyRequest.getCompanyCode());
            existingPolicy.setCoverageAmount(policyRequest.getCoverageAmount());
            policyRepository.save(existingPolicy);
            return ResponseEntity.ok(existingPolicy);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/policies/{id}")
    public ResponseEntity<Void> deletePolicy(@PathVariable long id) {
        return policyRepository.findById(id).map(policy -> {
            policyRepository.delete(policy);
            return ResponseEntity.ok().<Void>build();
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }    
}
