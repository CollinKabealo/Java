module Lab2Solution {
}