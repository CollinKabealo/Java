package edu.cscc;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

//Collin Kabealo, 9/13/2023, HTML file creation
public class Lab02 {
	//html header
	private static String pre = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<title>Natural Arches"+
			"</title>\n<meta charset=\"utf-8\">\n</head>\n<body>\n"+
			"<h1>Ohio Natural Arches</h1>\n<ul>\n";
	//html footer	
	private static String post = "</ul>\n</body>\n</html>\n";
	
	
	
	public static void main(String[] args) {
		//Makes the BufferedWriter for the writing of the file  		
		BufferedWriter bw = null;
		//Reference's to input the data file 		
		File file = new File("Lab2Data.txt");
		//Scanner to read file		
		try ( Scanner input = new Scanner(file); ) {
			//Initializes BufferedWriter for html file output			
			bw = new BufferedWriter(new FileWriter(new File("arches.html")));			
			//Writes html file header			
			bw.write(pre); 			
			//Skips header in data file			
			input.nextLine();
			//Processes each line of the data file			
			while(input.hasNext()) {
				//Reads line				
				String str = input.nextLine();
				//Converts to html format 				
				String htmlOutput = processLine(str);
				//Writes line to output file                
				bw.write(htmlOutput);				
			}
			//Writes html footer to the file
			bw.write(post);
		} catch(FileNotFoundException ex) {
			//Handles file not found exception			
			System.out.println(ex.getMessage());
		} catch (IOException ex2) {
			//Handles IO exception			
			System.out.println(ex2.getMessage());
		} finally {
			// Ensures the BufferedWriter closes correctly           
			if (bw != null) {
                try {
                    bw.close();
                //Ignores exception while closing
                } catch (IOException e) {
                    
                }
            }
		}    
		//Prints message of html file creation success 
		System.out.println("HTML file generated!");
	}
	//Makes single line of data input into html format
	public static String processLine(String line) {
        //Use of StringBuilder for effective string manipulating 
		StringBuilder sb = new StringBuilder();
        //Splits the line of input by the commas
		String[] parts = line.split(",");
		
		//Extracts needed data pieces
        String name = parts[0];
        String county = parts[1];
        String park = parts[2];
        String[] geoCoord = parts[3].split(" ");
        
        //Makes geoCoord. into decimal format
        double decLat = convertToDecimal(geoCoord[0], geoCoord[1], geoCoord[2], geoCoord[3]);
        double decLong = convertToDecimal(geoCoord[4], geoCoord[5], geoCoord[6], geoCoord[7]);
        
        //Builds the html string using StringBuilder
        sb.append("<li><a href=\"https://www.google.com/maps/search/?api=1&query=")
        		//"%.4f" makes sure the coordinate output is only to the fourth decimal place
        		.append(String.format("%.4f", decLat)).append(",").append(String.format("%.4f", decLong))
        		.append("\">").append(name)
        		.append("</a> at coordinates (").append(String.format("%.4f", decLat)).append(",").append(String.format("%.4f", decLong))
        		.append(") is located at ").append(park).append(" in ").append(county).append(" County</li>\n");

        //Returns built html string	
        return sb.toString();
    }
	
	
	//Makes geoCoord. into degs., mins., & secs.
    public static double convertToDecimal(String degs, String mins, String secs, String direct) {
        double deg = Double.parseDouble(degs.substring(0, degs.length() - 1));
        double min = Double.parseDouble(mins.substring(0, mins.length() - 1));
        double sec = Double.parseDouble(secs.substring(0, secs.length() - 1));

        //Makes into decimal 
        double decimalValue = deg + (min / 60.0) + (sec / 3600.0);
        //Adjust decimalValue taking into account direction
        if (direct.equals("S") || direct.equals("W")) {
            decimalValue = -decimalValue;
        }
        return decimalValue;
    }

}
