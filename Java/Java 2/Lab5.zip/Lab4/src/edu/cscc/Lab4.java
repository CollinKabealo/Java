package edu.cscc;

import java.sql.*;
import java.util.Scanner;

public class Lab4 {
	//The credentials for the database
	static final String USER = "rdonly";
    static final String PASS = "purpleAvocado218";
    static final String PORT = "1433";
    static final String HOST = "csci2469-01.czlyasswa9el.us-east-2.rds.amazonaws.com";
    static final String DATABASE = "AcmeCorp";
    //Builds the connection URL
    static final String connectionURL = "jdbc:sqlserver://" + HOST + ":" + PORT +
            ";databaseName=" + DATABASE + ";user=" + USER + ";password=" + PASS +
            ";encrypt=true;TrustServerCertificate=true";

    public static void main(String[] args) {
        System.out.println("Customer Search by Country");
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter country: ");
        String userCountry = scanner.nextLine();
        
        //Querying from the Customers table from Northwind
        try (Connection conn = DriverManager.getConnection(connectionURL);
             PreparedStatement stmt = conn.prepareStatement("SELECT CompanyName, Address, City, Region, PostalCode, Country FROM [Northwind].[dbo].[Customers] WHERE Country = ?")) {

            stmt.setString(1, userCountry);

            try (ResultSet rs = stmt.executeQuery()) {
                System.out.printf("%-35s %-45s %-20s %-20s %-15s %-25s%n",
                        "Company Name", "Address", "City", "Region", "Postal", "Country");
                System.out.println("===========================================================================================================================================");
                
                //Adjusts the widths for headers and data to make them line up
                //Takes the data from result set and prints it into columns
                while (rs.next()) {
                    System.out.printf("%-35s %-45s %-20s %-20s %-15s %-25s%n",
                            formatOtpt(rs.getString("CompanyName")),
                            formatOtpt(rs.getString("Address")),
                            formatOtpt(rs.getString("City")),
                            formatOtpt(rs.getString("Region")),
                            formatOtpt(rs.getString("PostalCode")),
                            formatOtpt(rs.getString("Country")));
                }
            }
        } catch (SQLException se) {
        	//Handles errors for JDBC
        	se.printStackTrace();
        }

        System.out.println("Done! Bye!");
    }

    private static String formatOtpt(String field) {
        return (field == null || field.isEmpty()) ? "n/a" : field.trim();
    }
}
