package edu.cscc;

public enum PizzaTopping {
	CHEESE, PEPPERONI, VEGGIE, CARNIVORE
}
