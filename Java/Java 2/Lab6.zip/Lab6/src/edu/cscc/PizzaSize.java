package edu.cscc;

public enum PizzaSize {
	SMALL, MEDIUM, LARGE
}
