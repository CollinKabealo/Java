package edu.cscc;

public enum PizzaType {
	REGULAR, THIN, DEEPDISH, NOCRUST
}
