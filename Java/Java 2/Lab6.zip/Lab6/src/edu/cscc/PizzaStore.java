package edu.cscc;

//Collin M. Kabealo, 10/11/2023, Lab 6  
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class PizzaStore {
    //The database connection properties
	private final String user;
    private final String pass;
    private final String port;
    private final String host;
    private final String database;
    
    private String connectionURL = null;
    
    //The prefix for the table based on my email
    private static final String prefix = "ckabealo";  
    
    //Makes the table using the prefix
    private static String ordersTableName = prefix+"_Orders";
    
    //SQL to delete the orders table
    private static final String DELETE_DDL = "DROP TABLE IF EXISTS "+ordersTableName+";";
    
    //SQL to create the orders table 
    private static final String CREATE_DDL = 
        "CREATE TABLE "+ordersTableName+"(" + 
            "id INT NOT NULL IDENTITY PRIMARY KEY," +
            "quantity INT NOT NULL, "+
            "orderDate VARCHAR(40) NOT NULL," +
            "size VARCHAR(10) NOT NULL,"+ 
            "type VARCHAR(10) NOT NULL,"+ 
            "toppings VARCHAR(10) NOT NULL);";
    
    //SQL statement to insert the new order into the orders table
    private final static String INSERTSQL = "INSERT INTO "+ordersTableName+"(quantity,orderDate,size,type,toppings) VALUES(?,?,?,?,?);";
    
    //Constructor that initializes PizzaStore with database credentials 
    public PizzaStore(String user, String pass, String port, String host, String database) {
        this.user = user;
        this.pass = pass;
        this.port = port;
        this.host = host;
        this.database = database;
        this.connectionURL = "jdbc:sqlserver://" + host + ":" + port + ";databaseName=" + database + ";user=" + user
                + ";password=" + pass + ";encrypt=true;TrustServerCertificate=true";
    }
    
    //Method that creates orders table
    public boolean createOrdersTable() {
        boolean result = true;
        try (Connection conn = DriverManager.getConnection(connectionURL);
             Statement stmt = conn.createStatement()) {

            // Delete the orders table if it exists
            stmt.execute(DELETE_DDL);

            // Create the orders table
            stmt.execute(CREATE_DDL);

        } catch (SQLException e) {
            System.out.println(connectionURL);
            System.out.println(e.getMessage());
            e.printStackTrace();
            result = false;
        }
        return result;
    }
    
    //Method to place pizza order by adding the record to the pizza orders table
    public boolean placeOrder(PizzaOrder order) {
        int numrows = 0;
        try (Connection conn = DriverManager.getConnection(connectionURL);
             PreparedStatement pstmt = conn.prepareStatement(INSERTSQL)) {

            pstmt.setInt(1, order.getQuantity());
            pstmt.setString(2, order.getOrderDate());
            pstmt.setString(3, order.getSize().toString());
            pstmt.setString(4, order.getType().toString());
            pstmt.setString(5, order.getTopping().toString());

            numrows = pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return (numrows == 1);
    }
    
    //The getters for the different properties 
    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }

    public String getPort() {
        return port;
    }

    public String getHost() {
        return host;
    }

    public String getDatabase() {
        return database;
    }
}
