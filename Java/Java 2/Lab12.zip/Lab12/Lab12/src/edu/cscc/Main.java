// Declares the package name and import the required libraries.
// Collin Kabealo, 4/20/2023
package edu.cscc;

import java.io.File;
import java.util.Set;

public class Main {
    // Declares the filename we want to process.
    private static final String fname = "The-Adventure-of-the-Empty-House.txt";
    // This is the main method that will execute when the program is run.
    public static void main(String[] args) {
        // Creates a File object with the given filename.
        File myfile = new File(fname);

        // Calls the processDocument method from UniqueWords class and pass our File object to it.
        Set<String> uniques = UniqueWords.processDocument(myfile);

        // Iterates over the Set of unique words and print them to the console.
        for (String s : uniques) {
            System.out.println(s);
        }

        // Prints the total number of unique words we found in the document.
        System.out.println("Got "+uniques.size()+" words");
    }
}