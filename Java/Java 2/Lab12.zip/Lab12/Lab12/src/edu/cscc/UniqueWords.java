/**

 The UniqueWords class is a utility for processing a document to create a sorted set of unique words.
 */
package edu.cscc;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class UniqueWords {
    /**
     * This method reads a file line by line and tokenizes it into individual words.
     * It stores the unique words in a sorted set.
     *
     * @param myfile the input file
     * @return a sorted set of unique words
     */
    public static Set<String> processDocument(File myfile) {
        TreeSet<String> set = new TreeSet<>();
        try (Scanner input = new Scanner(myfile);) {
            while (input.hasNext()) {
                String s = input.nextLine();
                // Tokenize the line into individual words
                String[] whatever = tokenize(s);
                for (String somename : whatever) {
                    // Add each word to the sorted set
                    set.add(somename);
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Cannot access file " + myfile.getName());
        }
        return set;
    }

    /**
     * This method removes all punctuation and numbers from a string, tokenizes it into individual words,
     * and converts all words to lower case.
     *
     * @param str the initial non-null string
     * @return an array of words from the initial string
     */
    public static String[] tokenize(String str) {
        str = str.replaceAll("[^a-zA-Z \n]", " "); // Remove all punctuation and numbers
        String[] tok = str.split(" "); // Tokenize into individual words
        for (int i = 0; i < tok.length; ++i) {
            tok[i] = tok[i].toLowerCase(); // Convert each word to lower case
        }
        return tok;
    }
}