package edu.cscc.controller;

import edu.cscc.model.Record;
import edu.cscc.repository.repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Controller
public class controller<S> {

    @Autowired
    private repository recordRepository;

    @GetMapping("/add-record")
    public String showAddRecordForm(Model model) {
        model.addAttribute("record", new Record());
        return "add-record";
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/add-record")
    public String addRecord(@Valid @ModelAttribute("record") Record record, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-record";
        }

        recordRepository.save((Iterable<S>) record);
        return "redirect:/records/" + record.getId();
    }

    @GetMapping("/records")
    public String listRecords(Model model) {
        Iterable<Record> records = recordRepository.findAll();
        model.addAttribute("records", records);
        return "records";
    }

    @GetMapping("/records/{id}")
    public String viewRecord(@PathVariable("id") long id, Model model) {
        Record record = recordRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid record Id:" + id));
        model.addAttribute("record", record);
        return "record";
    }
}
