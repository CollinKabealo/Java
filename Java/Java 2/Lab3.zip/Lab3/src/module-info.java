//Collin M. Kabealo, 9/19/2023
module Lab3 {
}