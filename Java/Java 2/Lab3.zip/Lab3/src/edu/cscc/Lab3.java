package edu.cscc;
//Collin M. Kabealo, Lab 3-Regular Expressions, 9/21/2023
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lab3 {

    public static void main(String[] args) {
        //Defines the ptrn(s) for acceptable phone number forms
        //This is for the (NXX) XXX-XXXX form
        Pattern ptrn1 = Pattern.compile("\\([2-9][0-9]{2}\\) [0-9]{3}-[0-9]{4}");
        //This is for the NXX-XXX-XXXX form
        Pattern ptrn2 = Pattern.compile("[2-9][0-9]{2}-[0-9]{3}-[0-9]{4}");
        //This is for the NXXXXXXXXX form
        Pattern ptrn3 = Pattern.compile("[2-9][0-9]{9}");

        //Try-with-resources closes BufferedReader
        try (BufferedReader reader = new BufferedReader(new FileReader("phoneno.txt"))) {
        	//Holds each line (phone number) from the file
        	String line;  
        	//Tracks line numbers
        	int lineNumber = 0;  

            //Reads each line from the file until end of file is reached
            while ((line = reader.readLine()) != null) {
                lineNumber++;

                //Matches each line ptrn(s)
                Matcher match1 = ptrn1.matcher(line);
                Matcher match2 = ptrn2.matcher(line);
                Matcher match3 = ptrn3.matcher(line);

                //If the line doesn't match any of the ptrn(s) it's an invalid phone number
                if (!match1.matches() && !match2.matches() && !match3.matches()) {
                    System.out.println("Line " + lineNumber + ": Invalid phone number \"" + line + "\"");
                }
            }

            //Indication of the end of validation
            System.out.println("Done");
         
        //Handles the possible IO exceptions    
        } catch (IOException e) {  
            e.printStackTrace();
        }
    }
}

