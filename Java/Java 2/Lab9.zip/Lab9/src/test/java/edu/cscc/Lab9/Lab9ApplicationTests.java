package edu.cscc.Lab9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
