package edu.cscc.Lab9.model;

public class Order {
	public int id;
	public int quantity;
	public String firstName;
	public String lastName;
	public long price;
	public Order(int id, int quantity, String firstName, String lastName, long price) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.firstName = firstName;
		this.lastName = lastName;
		this.price = price;
	}
}
