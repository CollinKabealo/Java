package edu.cscc.Lab9.model;

public class OrderRequest {
	public int quantity;
	public String firstName;
	public String lastName;
	public long price;
	public OrderRequest(int quantity, String firstName, String lastName, long price) {
		super();
		this.quantity = quantity;
		this.firstName = firstName;
		this.lastName = lastName;
		this.price = price;
	}
}
