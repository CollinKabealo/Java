package edu.cscc.Lab9.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import edu.cscc.Lab9.model.Order;
import edu.cscc.Lab9.model.OrderRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/orders")
public class OrderController {

    private final Map<Integer, Order> orders = new HashMap<>();
    private final AtomicInteger idCounter = new AtomicInteger();

    @GetMapping
    public ResponseEntity<Collection<Order>> getAllOrders() {
        return new ResponseEntity<>(orders.values(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable int id) {
        Order order = orders.get(id);
        return order != null ? new ResponseEntity<>(order, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest orderRequest) {
        int id = idCounter.incrementAndGet();
        Order newOrder = new Order(id, orderRequest.quantity, orderRequest.firstName, orderRequest.lastName, orderRequest.price);
        orders.put(id, newOrder);
        return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable int id) {
        if (orders.containsKey(id)) {
            orders.remove(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
