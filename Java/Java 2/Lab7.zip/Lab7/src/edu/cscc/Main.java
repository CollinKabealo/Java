package edu.cscc;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import org.json.*;

//Collin M. Kabealo, 10/19/2023, Lab 7 
public class Main {

    public static void main(String[] args) {
        final String theURLString = "http://api.open-notify.org/astros.json";

        try {
            //Reads the input from the URL and stores in a String
            String jsonString = readFromURL(theURLString);
            System.out.println(jsonString);

            //Uses org.json to parse JSON and determine number of people in space
            JSONObject jsonObject = new JSONObject(jsonString);
            int numberOfPeople = jsonObject.getInt("number");
            System.out.println("\nThere are " + numberOfPeople + " people in space");

            //Parses the list of people in space and locations
            JSONArray peopleArray = jsonObject.getJSONArray("people");
            for (int i = 0; i < peopleArray.length(); i++) {
                JSONObject person = peopleArray.getJSONObject(i);
                String name = person.getString("name");
                String craft = person.getString("craft");
                System.out.println(name + " is onboard: " + craft);
            }
        
        //Handles exceptions that may occur
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    //Reads from the URL and returns a string
    private static String readFromURL(String urlString) throws MalformedURLException, IOException {
        StringBuilder response = new StringBuilder();
        URL url = new URL(urlString);
        URLConnection connection = url.openConnection();
        
        //Uses BufferedReader to read from InputStream
        try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        }
        return response.toString();
    }
}