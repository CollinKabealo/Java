module AstrosSolution {
	requires org.json;
}